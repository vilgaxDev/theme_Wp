	<div id="sidebar"  class="fourcol woocommerce p-border">
    
    	<?php if ( is_active_sidebar( 'tmnf-sidebar' ) ) { ?>
        
            <div class="widgetable p-border">
    
                <?php dynamic_sidebar('tmnf-sidebar')?>
            
            </div>
            
		<?php } ?>
        
    </div><!-- #sidebar --> 