<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo( 'charset' ); ?>">
<!-- Set the viewport width to device width for mobile -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

    <div class="wrapper_main <?php $themnific_redux = get_option( 'themnific_redux' ); 
        if (empty($themnific_redux['tmnf-uppercase'])) {} else {if($themnific_redux['tmnf-uppercase'] == '1') echo 'upper '; }
        if (empty($themnific_redux['tmnf-letter-space'])) {} else {if($themnific_redux['tmnf-letter-space'] == '1') echo 'letter_space '; }
        if (empty($themnific_redux['tmnf-post-meta-dis'])) {} else {if($themnific_redux['tmnf-post-meta-dis'] == '1') echo 'meta_disabled '; }
        if ( is_active_sidebar( 'tmnf-sidebar' ) ) {echo 'tmnf-sidebar-active ';} else { echo 'tmnf-sidebar-null ';};
        if ( has_nav_menu( 'magazine-menu' ) ) {echo 'tmnf-menu-active ';}
        if (empty($themnific_redux['tmnf-header-layout'])) {} else {echo esc_attr($themnific_redux['tmnf-header-layout']);}
    ?>">
    
        <div class="wrapper">
        
            <div class="wrapper_inn">
            
                <div id="header" itemscope itemtype="https://schema.org//WPHeader">
                    <div class="clearfix"></div>
                    
                    <?php 
                    $themnific_redux = get_option( 'themnific_redux' );
                    $header_layout = $themnific_redux['tmnf-header-layout'];
                    
                    if (empty($themnific_redux['tmnf-header-layout'])) {get_template_part('/includes/header_classic' );} else {
                        if($header_layout == 'header_slim'){
                            get_template_part('/includes/header_slim' );
                            
                            }elseif($header_layout == 'header_centered'){
                            get_template_part('/includes/header_centered' );
                            
                            }elseif($header_layout == 'header_centered_2'){
                            get_template_part('/includes/header_centered_2' );
                            
                            } else {
                            get_template_part('/includes/header_classic' );
                        }
                    }
                    ?>
                    
                    <div class="clearfix"></div>
                    
                </div><!-- end #header  -->
        
    <div class="main_part">