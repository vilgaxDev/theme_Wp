                    <div class="clearfix"></div>
                    
                    <div id="footer" class="p-border">
                
                        <div class="footer-below p-border">
                                
                            <?php if ( function_exists('has_nav_menu') && has_nav_menu('bottom-menu') ) {wp_nav_menu( array( 'depth' => 1, 'sort_column' => 'menu_order', 'container' => 'ul', 'menu_class' => 'bottom-menu', 'menu_id' => '' , 'theme_location' => 'bottom-menu') );}  ?>
                            
                        </div>
                        
                        
                    
                        <div class="container container_alt woocommerce"> 
                        
                            <?php get_template_part('/includes/uni-bottombox'); ?>
                                    
                        </div>
                        
                        <div class="clearfix"></div>
                        <?php
                        $themnific_redux = get_option( 'themnific_redux' );
                        if (empty($themnific_redux['tmnf-search-bottom-dis'])) {
                        } else {?>
                            <div class="footer_icons">
                                <div class="container">
                                    <?php get_template_part('/includes/head_social' );
                                    if (empty($themnific_redux['tmnf-mailchimp'])) {
                                        } else {?> 
                                            <div class="mailchimp_section_alt">
                                                <?php echo do_shortcode(esc_attr($themnific_redux['tmnf-mailchimp']));?>
                                            </div>
                                    <?php } 
                                    ?>
                        
                                    <?php $themnific_redux = get_option( 'themnific_redux' );
                                        if(empty($themnific_redux['tmnf-footer-editor'])) { } else {
                                            echo '<div class="footer_text">' . wp_kses_post($themnific_redux['tmnf-footer-editor']). '</div>';
                                        }
                                    ?>
                                </div>
                            </div>
                        <?php } ?>
                        <div class="clearfix"></div>
                            
                    </div><!-- /#footer  -->
                    
                <div class="clearfix"></div>
                
                </div>
                
            </div>
            
            <div id="curtain" class="tranz">
                
                <?php get_search_form();?>
                
                <a class='curtainclose rad' href="<?php esc_url('#'); ?>" ><i class="fa fa-times"></i></a>
                
            </div>
                
            <div class="scrollTo_top ribbon">
            
                <a title="<?php esc_attr_e('Scroll to top','gutenverse');?>" class="rad" href="<?php esc_url('#'); ?>">&uarr;</a>
                
            </div><!-- /.warpper_inn class  -->
        </div><!-- /.warpper class  -->
    </div><!-- /.upper class  -->
    <?php get_template_part('/sidebar-flyoff' ); ?> 
    <?php wp_footer(); ?>

</body>
</html>