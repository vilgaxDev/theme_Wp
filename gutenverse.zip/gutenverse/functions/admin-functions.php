<?php

/*-----------------------------------------------------------------------------------*/
/* REDUX - speciable */
/*-----------------------------------------------------------------------------------*/



// detect plugin 
if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
} else {
	
	function gutenverse_enqueue_reduxfall() {
		
		// Redux fallback
		wp_enqueue_style('reduxfall', get_template_directory_uri() . '/styles/reduxfall.css');
				
		// google link
		function tmnf_fonts_url() {
			$font_url = '';
			if ( 'off' !==  esc_attr_x( 'on', 'Google font: on or off','gutenverse')) {
				$font_url = add_query_arg( 'family', urlencode( 'Open Sans:400,700,400italic,700italic|Poppins:500,600|Source Sans Pro:900,800,700,600,400,500&subset=latin,latin-ext' ), "//fonts.googleapis.com/css" );
			}
			return $font_url;
		}
		wp_enqueue_style( 'gutenverse-fonts', tmnf_fonts_url(), array(), '1.0.0' );
		
	}
	add_action( 'wp_enqueue_scripts', 'gutenverse_enqueue_reduxfall' );
	
}

/*-----------------------------------------------------------------------------------*/
/* One Click Demo Import - speciable */
/*-----------------------------------------------------------------------------------*/


// detect plugin 
if ( class_exists( 'OCDI_Plugin' ) ) {

function tmnf_import_files() {
  return array(
  
  
  	// DEFAULT
    array(
      'import_file_name'           => 'Default Demo',
      'import_file_url'            => 'http://capethemes.com/docs/gutenverse/import/gutenverse.xml',
      'import_widget_file_url'     => 'http://capethemes.com/docs/gutenverse/import/gutenverse-widgets.wie',
      'import_redux'               => array(
        array(
          'file_url'    => 'http://capethemes.com/docs/gutenverse/import/gutenverse-redux.json',
          'option_name' => 'themnific_redux',
        ),
      ),
      'import_preview_image_url'   => 'http://capethemes.com/docs/gutenverse/import/gutenverse-screenshot.jpg',
      'preview_url'                => 'http://capethemes.com/demo/gutenverse/main/',
    ),
	
	
	  
  
  	// TRAVEL
    array(
      'import_file_name'           => 'Travel Demo',
      'import_file_url'            => 'http://capethemes.com/docs/gutenverse/import/travel/gutenverse-travel.xml',
      'import_widget_file_url'     => 'http://capethemes.com/docs/gutenverse/import/travel/gutenverse-travel-widgets.wie',
      'import_redux'               => array(
        array(
          'file_url'    => 'http://capethemes.com/docs/gutenverse/import/travel/gutenverse-travel-redux.json',
          'option_name' => 'themnific_redux',
        ),
      ),
      'import_preview_image_url'   => 'http://capethemes.com/docs/gutenverse/import/travel/gutenverse-travel-screenshot.jpg',
      'preview_url'                => 'http://capethemes.com/demo/gutenverse/travel/',
    ),
	
	
	  
  
  	// LIFESTYLE
    array(
      'import_file_name'           => 'Lifestyle Demo',
      'import_file_url'            => 'http://capethemes.com/docs/gutenverse/import/lifestyle/gutenverse-lifestyle.xml',
      'import_widget_file_url'     => 'http://capethemes.com/docs/gutenverse/import/lifestyle/gutenverse-lifestyle-widgets.wie',
      'import_redux'               => array(
        array(
          'file_url'    => 'http://capethemes.com/docs/gutenverse/import/lifestyle/gutenverse-lifestyle-redux.json',
          'option_name' => 'themnific_redux',
        ),
      ),
      'import_preview_image_url'   => 'http://capethemes.com/docs/gutenverse/import/lifestyle/gutenverse-lifestyle-screenshot.jpg',
      'preview_url'                => 'http://capethemes.com/demo/gutenverse/lifestyle/',
    ),
	
	
	  
  
  	// newspaper
    array(
      'import_file_name'           => 'Newspaper Demo',
      'import_file_url'            => 'http://capethemes.com/docs/gutenverse/import/newspaper/gutenverse-newspaper.xml',
      'import_widget_file_url'     => 'http://capethemes.com/docs/gutenverse/import/newspaper/gutenverse-newspaper-widgets.wie',
      'import_redux'               => array(
        array(
          'file_url'    => 'http://capethemes.com/docs/gutenverse/import/newspaper/gutenverse-newspaper-redux.json',
          'option_name' => 'themnific_redux',
        ),
      ),
      'import_preview_image_url'   => 'http://capethemes.com/docs/gutenverse/import/newspaper/gutenverse-newspaper-screenshot.jpg',
      'preview_url'                => 'http://capethemes.com/demo/gutenverse/newspaper/',
    ),
	
	
	  
  
  	// TRAVEL
    array(
      'import_file_name'           => 'Personal Demo',
      'import_file_url'            => 'http://capethemes.com/docs/gutenverse/import/personal/gutenverse-personal.xml',
      'import_widget_file_url'     => 'http://capethemes.com/docs/gutenverse/import/personal/gutenverse-personal-widgets.wie',
      'import_redux'               => array(
        array(
          'file_url'    => 'http://capethemes.com/docs/gutenverse/import/personal/gutenverse-personal-redux.json',
          'option_name' => 'themnific_redux',
        ),
      ),
      'import_preview_image_url'   => 'http://capethemes.com/docs/gutenverse/import/personal/gutenverse-personal-screenshot.jpg',
      'preview_url'                => 'http://capethemes.com/demo/gutenverse/personal/',
    ),
	
	
	  
  
  	// minimalist
    array(
      'import_file_name'           => 'Minimalist Demo',
      'import_file_url'            => 'http://capethemes.com/docs/gutenverse/import/minimalist/gutenverse-minimalist.xml',
      'import_widget_file_url'     => 'http://capethemes.com/docs/gutenverse/import/minimalist/gutenverse-minimalist-widgets.wie',
      'import_redux'               => array(
        array(
          'file_url'    => 'http://capethemes.com/docs/gutenverse/import/minimalist/gutenverse-minimalist-redux.json',
          'option_name' => 'themnific_redux',
        ),
      ),
      'import_preview_image_url'   => 'http://capethemes.com/docs/gutenverse/import/minimalist/gutenverse-minimalist-screenshot.jpg',
      'preview_url'                => 'http://capethemes.com/demo/gutenverse/minimalist/',
    ),
	
	
	  
  
  	// vintage
    array(
      'import_file_name'           => 'Vintage Demo',
      'import_file_url'            => 'http://capethemes.com/docs/gutenverse/import/vintage/gutenverse-vintage.xml',
      'import_widget_file_url'     => 'http://capethemes.com/docs/gutenverse/import/vintage/gutenverse-vintage-widgets.wie',
      'import_redux'               => array(
        array(
          'file_url'    => 'http://capethemes.com/docs/gutenverse/import/vintage/gutenverse-vintage-redux.json',
          'option_name' => 'themnific_redux',
        ),
      ),
      'import_preview_image_url'   => 'http://capethemes.com/docs/gutenverse/import/vintage/gutenverse-vintage-screenshot.jpg',
      'preview_url'                => 'http://capethemes.com/demo/gutenverse/vintage/',
    ),  
	
	
  	// digital nomad
    array(
      'import_file_name'           => 'Digital Nomad',
      'import_file_url'            => 'http://capethemes.com/docs/gutenverse/import/digital/gutenverse-digitalnomad.xml',
      'import_widget_file_url'     => 'http://capethemes.com/docs/gutenverse/import/digital/gutenverse-digitalnomad-widgets.wie',
      'import_redux'               => array(
        array(
          'file_url'    => 'http://capethemes.com/docs/gutenverse/import/digital/gutenverse-digitalnomad-redux.json',
          'option_name' => 'themnific_redux',
        ),
      ),
      'import_preview_image_url'   => 'http://capethemes.com/docs/gutenverse/import/digital/gutenverse-digitalnomad-screenshot.jpg',
      'preview_url'                => 'http://dannci.wpmasters.org/gutenverse/digital-nomad/',
    ),
	
	
	
	// END OF ARRAY
	
  );
}
add_filter( 'pt-ocdi/import_files', 'tmnf_import_files' );


function tmnf_after_import_setup() {
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

    set_theme_mod( 'nav_menu_locations', array(
            'main-menu' => $main_menu->term_id,
        )
    );

    // Assign front page and posts page (blog page).
    $front_page_id = get_page_by_title( 'Home' );
    $blog_page_id  = get_page_by_title( 'News' );

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'page_for_posts', $blog_page_id->ID );

}
add_action( 'pt-ocdi/after_import', 'tmnf_after_import_setup' );

add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );

}

/*-----------------------------------------------------------------------------------*/
/* THE END */
/*-----------------------------------------------------------------------------------*/
?>