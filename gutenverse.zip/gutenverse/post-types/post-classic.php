				<div <?php post_class('item item_small'); ?>>  
                    <?php if ( has_post_thumbnail()){?>
                    	<div class="imgwrap">
							<?php echo gutenverse_icon();?>
                            <div class="icon-rating tranz"><?php if (function_exists('wp_review_show_total')) wp_review_show_total(); ?></div>
                            <a href="<?php gutenverse_permalink(); ?>">
                                <?php the_post_thumbnail('gutenverse_blog',array('class' => 'standard grayscale grayscale-fade'));?>
                            </a>
                        </div>
                    <?php } ?> 	
                    <div class="item_inn tranz">
                        <h2 class="posttitle"><a class="link link--forsure" href="<?php gutenverse_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="clearfix"></div>
                        <?php gutenverse_meta_front();?>
                        <div class="clearfix"></div>
                    	<p class="teaser"><?php echo gutenverse_excerpt( get_the_excerpt(), '140'); ?><span class="helip">...</span></p>
                        <?php gutenverse_meta_more(); ?>
                    </div><!-- end .item_inn -->     
                </div><!-- end .item -->