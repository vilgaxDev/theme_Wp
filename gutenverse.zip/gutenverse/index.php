<?php get_header();
$themnific_redux = get_option( 'themnific_redux' );?>
    
<?php // blog content - start ?>

<?php 	
	$themnific_redux = get_option( 'themnific_redux' );
	if (empty($themnific_redux['tmnf-blog-layout'])) {} else {
		$themnific_blog_layout = $themnific_redux['tmnf-blog-layout']; 
	}
?>
<div id="core"> 
 
    <div class="container_alt">
    
        <div id="content" class="eightcol">
        
        	<div class="<?php if (empty($themnific_redux['tmnf-blog-layout'])) {echo 'blogger';} else {
				if($themnific_blog_layout == 'blog_layout'){
						echo 'blogger';
					}elseif($themnific_blog_layout == 'blog_layout_2'){
						echo 'blogger blog_layout_2';
					}elseif($themnific_blog_layout == 'blog_layout_list'){
						echo 'blogger blog_layout_list';
					} else {
						echo 'blogger';
				}
			} ?>">
            
				<?php 
                $loop_counter = 1;
                if (have_posts()) :  while (have_posts()) : the_post();
                    if($loop_counter   == 2 ||$loop_counter   == 3):
                        get_template_part('/post-types/post-classic');
                     else:
                          if (empty($themnific_redux['tmnf-blog-layout'])) {get_template_part('/post-types/post-classic-big');} else {
                              if($themnific_blog_layout == 'blog_layout'){
                                    get_template_part('/post-types/post-classic-big');
                                  }elseif($themnific_blog_layout == 'blog_layout_2'){
                                    get_template_part('/post-types/post-classic');
                                  }elseif($themnific_blog_layout == 'blog_layout_list'){
                                    get_template_part('/post-types/post-classic');
                                  } else {
                                    get_template_part('/post-types/post-classic-big');
                              }
                          }  
                        $loop_counter = 1;//reset counter
                      endif; 
                $loop_counter++;
                endwhile; ?><!-- end post -->
                
                <div class="clearfix"></div>
                
            </div><!-- end .blogger-->
            
            <div class="clearfix"></div>
            
            <div class="pagination"><?php the_posts_pagination(); ?></div>
            
            <?php else : ?>
            
                <div class="errorentry entry ghost">
                
                    <h1 class="post entry-title" itemprop="headline"><?php esc_html_e('Nothing found here','gutenverse');?></h1>
                    
                    <h4><?php esc_html_e('Perhaps You will find something interesting from these lists...','gutenverse');?></h4>
                    
                    <div class="hrline"></div>
                    
                    <?php get_template_part('/includes/uni-404-content');?>
                    
                </div>
                
            </div><!-- end .blogger 2nd -->
            
            <?php  endif;  ?>
            
            <div class="clearfix"></div>
            
        </div><!-- end .content -->
        
		<?php get_sidebar();?>
        
    </div><!-- end .container -->
    
</div><!-- end #core -->	

<?php // blog content - end ?>
<?php get_footer(); ?>