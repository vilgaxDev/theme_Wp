jQuery(document).ready(function(){
/*global jQuery:false */
/*jshint devel:true, laxcomma:true, smarttabs:true */
"use strict";

	// show navigation when scroll up
	var c, currentScrollTop = 0,
	 navbar = jQuery('.will_stick');
	
	jQuery(window).scroll(function () {
		var a = jQuery(window).scrollTop() -200;
		var b = navbar.height();
		
		currentScrollTop = a;
		
		if (c < currentScrollTop && a > b + b) {
		  navbar.addClass("scrollUp");
		} else if (c > currentScrollTop && !(a <= b)) {
		  navbar.removeClass("scrollUp");
		}
		c = currentScrollTop;
	});
	// fix navigation when scroll down 400px
	jQuery(".will_stick");
	jQuery(function () {
		jQuery(window).scroll(function () {
			if (jQuery(this).scrollTop() > 400) {
				jQuery('.will_stick').addClass("scrollDown")
			} else {
				jQuery('.will_stick').removeClass("scrollDown")
			}
		});
	});


	// scroll to top
	jQuery(".scrollTo_top").hide();
	jQuery(function () {
		jQuery(window).scroll(function () {
			if (jQuery(this).scrollTop() > 100) {
				jQuery('.scrollTo_top').fadeIn();
			} else {
				jQuery('.scrollTo_top').fadeOut();
			}
		});

	jQuery('.scrollTo_top a').on('click',function(){
		jQuery('html, body').animate({scrollTop:0}, 500 );
		return false;
	});
	});
		
	// searchtrigger
	jQuery('a.searchOpen').on('click',function(){ 
			jQuery('#curtain').toggleClass('open'); 
            jQuery(this).toggleClass('opened'); 
			return false; 
	}); 
	
	jQuery('a.curtainclose').on('click',function(){ 
			jQuery('#curtain').removeClass('open'); 
			jQuery('a.searchOpen').removeClass('opened');
			return false; 
	});
	
	/* menutrigger */
	jQuery('a.menuOpen').on('click',function(){ 
            jQuery(this).toggleClass('opened'); 
			jQuery('#flyoff').toggleClass('visible'); 
			jQuery('.action-overlay').toggleClass('visible');
			jQuery('body').toggleClass('flyoff-is-visible');
			return false; 
	}); 
	
	jQuery('a.menuClose').on('click',function(){ 
			jQuery('a.menuOpen').removeClass('opened');
			jQuery('#flyoff').removeClass('visible');
			jQuery('.action-overlay').removeClass('visible');
			jQuery('body').removeClass('flyoff-is-visible');
			return false; 
	});
	
	jQuery('.action-overlay').on('click',function(){ 
			jQuery('a.menuOpen').removeClass('opened');
			jQuery('#flyoff').removeClass('visible');
			jQuery('.action-overlay').removeClass('visible');
			jQuery('body').removeClass('flyoff-is-visible');
			return false; 
	});



	// mobile menu
	
    jQuery(document).ready(function () {
        tmnf_dropdown_mobile();
    });
	
    window.tmnf_dropdown_mobile = () => {
        let windowW = jQuery(window).width();

        jQuery('#main-nav li.menu-item-has-children > a').each(function () {
            jQuery(this).append('<span class="tmnf_mobile_dropdown"></span>');
        });

        jQuery('body').find('.tmnf_mobile_dropdown').on('click', function (e) {
            e.preventDefault();
            let dd = jQuery(this);
            dd.closest('li').toggleClass(function () {
                if ( window.innerWidth < 868) {
                    let subMenu = dd.closest('li').children('.sub-menu');
                    subMenu.toggle();
                }
                return 'active';
            });
        });
    };

});