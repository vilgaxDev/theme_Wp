<?php

    if ( ! class_exists( 'gutenverse_redux_config' ) ) {

        class gutenverse_redux_config {

            public $args = array();
            public $sections = array();
            public $theme;
            public $ReduxFramework;

            public function __construct() {

                if ( ! class_exists( 'ReduxFramework' ) ) {
                    return;
                }

                $this->initSettings();

            }

            public function initSettings() {

                // Just for demo purposes. Not needed per say.
                $this->theme = wp_get_theme();

                // Set the default arguments
                $this->setArguments();

                // Set a few help tabs so you can see how it's done
                $this->setHelpTabs();

                // Create the sections and fields
                $this->setSections();

                if ( ! isset( $this->args['opt_name'] ) ) { // No errors please
                    return;
                }

                // If Redux is running as a plugin, this will remove the demo notice and links
                add_action( 'redux/loaded', array( $this, 'remove_demo' ) );

                // Function to test the compiler hook and demo CSS output.
                // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
                //add_filter('redux/options/'.$this->args['opt_name'].'/compiler', array( $this, 'compiler_action' ), 10, 3);

                // Change the arguments after they've been declared, but before the panel is created
                //add_filter('redux/options/'.$this->args['opt_name'].'/args', array( $this, 'change_arguments' ) );

                // Change the default value of a field after it's been set, but before it's been useds
                //add_filter('redux/options/'.$this->args['opt_name'].'/defaults', array( $this,'change_defaults' ) );

                // Dynamically add a section. Can be also used to modify sections/fields
                //add_filter('redux/options/' . $this->args['opt_name'] . '/sections', array($this, 'dynamic_section'));

                $this->ReduxFramework = new ReduxFramework( $this->sections, $this->args );
            }

            /**
             * This is a test function that will let you see when the compiler hook occurs.
             * It only runs if a field    set with compiler=>true is changed.
             * */
            function compiler_action( $options, $css, $changed_values ) {
                echo esc_html__( 'The compiler hook has run!','gutenverse' );
                echo "<pre>";
                print_r( esc_html($changed_values )); // Values that have changed since the last save
                echo "</pre>";
            }

            /**
             * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
             * Simply include this function in the child themes functions.php file.
             * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
             * so you must use get_template_directory_uri() if you want to use any of the built in icons
             * */
            function dynamic_section( $sections ) {
                //$sections = array();
                $sections[] = array(
                    'title'  => esc_html__( 'Section via hook','gutenverse' ),
                    'desc'   => esc_html__( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>','gutenverse' ),
                    'icon'   => 'el el-paper-clip',
                    // Leave this as a blank section, no options just some intro text set above.
                    'fields' => array()
                );

                return $sections;
            }

            /**
             * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
             * */
            function change_arguments( $args ) {
                //$args['dev_mode'] = true;

                return $args;
            }

            /**
             * Filter hook for filtering the default value of any given field. Very useful in development mode.
             * */
            function change_defaults( $defaults ) {
                $defaults['str_replace'] = 'Testing filter hook!';

                return $defaults;
            }

            // Remove the demo link and the notice of integrated demo from the redux-framework plugin
            function remove_demo() {

                // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
                if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                    remove_filter( 'plugin_row_meta', array(
                        ReduxFrameworkPlugin::instance(),
                        'plugin_metalinks'
                    ), null, 2 );

                    // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                    remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
                }
            }

            public function setSections() {

                ob_start();

                $ct          = wp_get_theme();
                $this->theme = $ct;
                $item_name   = $this->theme->get( 'Name' );
                $tags        = $this->theme->Tags;
                $screenshot  = $this->theme->get_screenshot();
                $class       = $screenshot ? 'has-screenshot' : '';

                $customize_title = sprintf( esc_html__( 'Customize &#8220;%s&#8221;','gutenverse' ), $this->theme->display( 'Name' ) );

                ?>
                <div id="current-theme" class="<?php echo esc_attr( $class ); ?>">
                    <?php if ( $screenshot ) : ?>
                        <?php if ( current_user_can( 'edit_theme_options' ) ) : ?>
                            <a href="<?php echo esc_url(wp_customize_url()); ?>" class="load-customize hide-if-no-customize"
                               title="<?php echo esc_attr( $customize_title ); ?>">
                                <img src="<?php echo esc_url( $screenshot ); ?>"
                                     alt="<?php esc_attr_e( 'Current theme preview','gutenverse' ); ?>"/>
                            </a>
                        <?php endif; ?>
                        <img class="hide-if-customize" src="<?php echo esc_url( $screenshot ); ?>"
                             alt="<?php esc_attr_e( 'Current theme preview','gutenverse' ); ?>"/>
                    <?php endif; ?>

                    <h4><?php echo esc_html($this->theme->display( 'Name' )); ?></h4>

                    <div>
                        <ul class="theme-info">
                            <li><?php printf( esc_html__( 'By %s','gutenverse' ), $this->theme->display( 'Author' ) ); ?></li>
                            <li><?php printf( esc_html__( 'Version %s','gutenverse' ), $this->theme->display( 'Version' ) ); ?></li>
                            <li><?php echo '<strong>' . esc_html__( 'Tags','gutenverse' ) . ':</strong> '; ?><?php printf( $this->theme->display( 'Tags' ) ); ?></li>
                        </ul>
                        <?php
                            if ( $this->theme->parent() ) {
                                printf( ' <p class="howto">' . esc_html__( 'This <a href="%1$s">child theme</a> requires its parent theme, %2$s.','gutenverse' ) . '</p>', esc_html__( 'http://codex.wordpress.org/Child_Themes','gutenverse' ), $this->theme->parent()->display( 'Name' ) );
                            }
                        ?>

                    </div>
                </div>

                <?php
                $item_info = ob_get_contents();

                ob_end_clean();

                $sampleHTML = '';

                // ACTUAL DECLARATION OF SECTIONS
                $this->sections[] = array(
                    'title'  => esc_html__( 'General Settings','gutenverse' ),
                    'desc'   => esc_html__( '','gutenverse' ),
                    'icon'   => 'el el-cogs',
                    'fields' => array( // header end
					

                        array(
                            'id'       => 'tmnf-main-logo',
                            'type'     => 'media',
							'default'  => '',
							'readonly' => false,
                            'preview'  => true,
							'url'      => true,
                            'title'    => esc_html__( 'Main Logo','gutenverse' ),
                            'desc'     => esc_html__( 'Upload a logo for your theme','gutenverse' ),
                        ),
												
                      	array(
                            'id'       => 'tmnf-blog-layout',
                            'type'     => 'radio',
                            'title'    => esc_html__('Blog Layout','gutenverse'),
                            'subtitle' => esc_html__('Select layout and styling for blog template','gutenverse'),
                            //Must provide key => value pairs for radio options
                            'options'  => array(
                                'blog_layout' => esc_html__('Blog Style 1 (big/small images)','gutenverse'),
                                'blog_layout_2' => esc_html__('Blog Style 2 (small images)','gutenverse'),
                                'blog_layout_list' => esc_html__('Blog Style 3 (posts list)','gutenverse'),
                            ),
                            'default'  => 'blog_layout'
                        ),
						
                        array(
                            'id'       => 'tmnf-uppercase',
                            'type'     => 'checkbox',
                            'title'    => esc_html__( 'Enable Uppercase Fonts','gutenverse' ),
                            'subtitle' => esc_html__( 'You can enable general uppercase here.','gutenverse' ),
                            'default'  => '1'// 1 = on | 0 = off
                        ),
						
                        array(
                            'id'       => 'tmnf-letter-space',
                            'type'     => 'checkbox',
                            'title'    => esc_html__( 'Additional Letter Space','gutenverse' ),
                            'default'  => '1'// 1 = on | 0 = off
                        ),
						
						array(
                            'id'       => 'tmnf-mailchimp',
                            'type'     => 'text',
                            'title'    => esc_html__( 'MailChimp Shortcode','gutenverse' ),
							'default'  => '',
                            'validate' => 'html',
						),
					
					// section end
                    )
                );
				// General Layout THE END
	



                $this->sections[] = array(
                    'type' => 'divide',
                );




                $this->sections[] = array(
                    'title'  => esc_html__( 'Primary Styling','gutenverse' ),
                    'desc'   => esc_html__( '','gutenverse' ),
                    'icon'   => 'el el-tint',
                    'fields' => array( // header end



						array(
                            'id'          => 'gutenverse-body-typography',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Typography','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => true,
                            'output'      => array( 'body,input,button,textarea' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography used as general text.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#3a3a3a',
                                'font-weight'  => '400',
                                'font-family' => 'Open Sans',
                                'google'      => true,
                                'font-size'   => '17px',
                            ),
                        ),

                        array(
                            'id'       => 'gutenverse-background',
                            'type'     => 'background',
                            'title'    => esc_html__( 'Main Body Background','gutenverse' ),
                            'subtitle' => esc_html__( 'Body background with image, color, etc.','gutenverse' ),
                            'output'   => array('.wrapper_inn,.postbar,.item_small.has-post-thumbnail .item_inn' ),
                            'default'     => array(
                                'background-color'       => '#fff',
                            ),
                        ),

                        array(
                            'id'       => 'gutenverse-ghost',
							'type'      => 'color',
							'title'     => esc_html__('Ghost Background Color','gutenverse'),
							'subtitle'  => esc_html__('Set alternative background color (similar to the Main Body Background) ','gutenverse'),
							'default'   => '#f9fbff',
							'output'    => array(
								'background-color' => '.ghost,.sidebar_item,#respond textarea,#respond input'
							)
						),

                        array(
                            'id'       => 'gutenverse-link-color',
                            'type'     => 'link_color',
                            'title'    => esc_html__( 'Links Color Option','gutenverse' ),
                            'subtitle' => esc_html__( 'Pick a link color','gutenverse' ),
							'output'   => array( 'a:not(.wp-block-button__link)' ),
                            'default'  => array(
                                'regular' => '#2d4044',
                                'hover'   => '#ff4f69',
                                'active'  => '#000',
                            )
                        ),
						

						
						array(
							'id'        => 'gutenverse-color-entry-link',
							'type'      => 'color',
							'title'     => esc_html__('Entry Links (in post texts)','gutenverse'),
							'subtitle'  => esc_html__('Pick a custom color for post links.','gutenverse'),
							'default'   => '#ff4f69',
							'output'    => array(
								'color' => '.entry p a,.site-title a,.entry ol a,.entry ul a',
								'border-color' => '.entry p a,.entry ol a,.entry ul a',
							)
						),
						

						
						array(
							'id'        => 'gutenverse-color-entry-link-hover',
							'type'      => 'color',
							'title'     => esc_html__('Entry Links (in post texts): Hover Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a custom color for post links.','gutenverse'),
							'default'   => '#dce2ea',
							'output'    => array(
								'background-color' => '.entry p a:hover,.site-title a:hover,.entry ol li>a:hover,.entry ul li>a:hover',
							)
						),
						
                        array(
                            'id'       => 'gutenverse-primary-border',
							'type'      => 'color',
							'title'     => esc_html__('Borders Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for primary borders','gutenverse'),
							'default'   => '#e6ecf5',
							'output'    => array(
								'border-color' => '.p-border,.sidebar_item,.sidebar_item  h5,.sidebar_item li,.sidebar_item ul.menu li,.block_title:after,.meta,.tagcloud a,.page-numbers,input,textarea,select,.page-link span,.post-pagination>p a',
							)
						),
						
						array(
							'id'        => 'gutenverse-text-sidebar',
							'type'      => 'color',
							'title'     => esc_html__('Sidebar Text Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for sidebar text.','gutenverse'),
							'default'   => '#3b505e',
							'output'    => array(
								'color' => '#sidebar',
							)
						),
						
						array(
							'id'        => 'gutenverse-links-sidebar',
							'type'      => 'color',
							'title'     => esc_html__('Sidebar Link Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for sidebar links.','gutenverse'),
							'default'   => '#2d4044',
							'output'    => array(
								'color' => '.widgetable a',
							)
						),


					// section end
                    )
                );
				// Primary styling THE END
				


                $this->sections[] = array(
                    'title'  => esc_html__( 'Header Styling','gutenverse' ),
                    'desc'   => esc_html__( '','gutenverse' ),
                    'icon'   => 'el el-tint',
                    'fields' => array( // header end
					
					
												
                      	array(
                            'id'       => 'tmnf-header-layout',
                            'type'     => 'radio',
                            'title'    => esc_html__('Header Layout','gutenverse'),
                            'subtitle' => esc_html__('Select layout for your header','gutenverse'),
                            //Must provide key => value pairs for radio options
                            'options'  => array(
                                'header_classic' => esc_html__('Classic Header','gutenverse'),
                                'header_slim' => esc_html__('Slim Header','gutenverse'),
                                'header_centered' => esc_html__('Centered Header','gutenverse'),
                                'header_centered_2' => esc_html__('Centered Header 2','gutenverse'),
                            ),
                            'default'  => 'header_classic'
                        ),
						
						array(
							'id'        => 'gutenverse-bg-myheader',
							'type'      => 'color',
							'title'     => esc_html__('Header Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a bg color for header. On mobile devices is transparent header disabled.','gutenverse'),
							'default'   => '#fff',
							'output'    => array(
								'background-color' => '#header',
							)
						),
						
						array(
							'id'        => 'gutenverse-links-myheader',
							'type'      => 'color',
							'title'     => esc_html__('Header Link Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for header links.','gutenverse'),
							'default'   => '#000',
							'output'    => array(
								'color' => '#header h1 a',
							)
						),
						
						array(
							'id'        => 'gutenverse-hover-myheader',
							'type'      => 'color',
							'title'     => esc_html__('Header Link Color: Hover Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a hover color for header links.','gutenverse'),
							'default'   => '#ff4f69',
							'output'    => array(
								'color' => '#titles a:hover,#header ul.social-menu a:hover',
							)
						),
						
						array(
							'id'        => 'gutenverse-borders-myheader',
							'type'      => 'color',
							'title'     => esc_html__('Header Borders Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a bg color for header. On mobile devices is transparent header disabled.','gutenverse'),
							'default'   => '#efefef',
							'output'    => array(
								'border-color' => '.header_row',
							)
						),
						
						array(
							'id'   => 'info_normal',
							'type' => 'info',
							'title' => esc_html__('Menu Section + Special menu button','gutenverse'),
							'style' => 'success',
						),
						
						array(
							'id'        => 'gutenverse-navbar-myheader',
							'type'      => 'color',
							'title'     => esc_html__('Navigation Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for header links.','gutenverse'),
							'default'   => '#fcfcfc',
							'output'    => array(
								'background-color' => '.will_stick',
							)
						),


						array(
                            'id'          => 'gutenverse-header-typography',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Navigation Typography','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( '.nav>li>a,.top_nav .searchform input.s' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography used as navigation text.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#000000',
                                'font-weight'  => '600',
                                'font-family' => 'Poppins',
                                'google'      => true,
                                'font-size'   => '15px',
                            ),
                        ),
						
						array(
							'id'        => 'gutenverse-hover-myheader',
							'type'      => 'color',
							'title'     => esc_html__('Navigation Link Color: Hover Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a hover color for header links.','gutenverse'),
							'default'   => '#ff4f69',
							'output'    => array(
								'color' => '.nav>li.current-menu-item>a,.nav>li>a:hover,.menu-item-has-children>a:after',
							)
						),
						
						array(
							'id'        => 'gutenverse-icons-myheader',
							'type'      => 'color',
							'title'     => esc_html__('Header Icons: Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a hover color for header icons.','gutenverse'),
							'default'   => '#000000',
							'output'    => array(
								'color' => '#header ul.social-menu li a,.head_extend a',
							)
						),
						
						array(
							'id'        => 'gutenverse-bg-submenu',
							'type'      => 'color',
							'title'     => esc_html__('Sub-menu Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a hover color for header links.','gutenverse'),
							'default'   => '#e7ecf5',
							'output'    => array(
								'background-color' => '.nav li ul',
								'border-bottom-color' => '.nav>li>ul:after',
								
							)
						),

						array(
                            'id'          => 'gutenverse-submenu-typography',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Sub-menu Typography','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( '.nav ul li>a' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography used as navigation text.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#071e30',
                                'font-weight'  => '500',
                                'font-family' => 'Poppins',
                                'google'      => true,
                                'font-size'   => '12px',
                            ),
                        ),
						
						array(
							'id'        => 'gutenverse-hover-submenu',
							'type'      => 'color',
							'title'     => esc_html__('Sub-menu Link Color: Hover Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a hover color for header links.','gutenverse'),
							'default'   => '#6b7391',
							'output'    => array(
								'color' => '.nav li ul li>a:hover',
							)
						),
						
						array(
							'id'        => 'gutenverse-header-special-bg',
							'type'      => 'color',
							'title'     => esc_html__('Menu Button: Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for header text.','gutenverse'),
							'default'   => '#e8ecf2',
							'output'    => array(
								'background-color' => '.show-menu,#main-nav>li.special>a',
								'color' => '.nav a i',
							)
						),
						
						
						array(
							'id'        => 'gutenverse-header-special-text',
							'type'      => 'color',
							'title'     => esc_html__('Menu Button: Text Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for header text.','gutenverse'),
							'default'   => '#6b7391',
							'output'    => array(
								'color' => '#header .show-menu,#main-nav>li.special>a',
							)
						),


						array(
							'id'   => 'info_normal',
							'type' => 'info',
							'title' => esc_html__('Spacing of the Header','gutenverse'),
							'style' => 'success',
						),

                        array(
                            'id'             => 'gutenverse-width-header',
                            'type'           => 'dimensions',
                            'output'   => array( '#titles' ),
                            'units'          => 'px', 
                            'units_extended' => 'true',  
                            'height'          => false, 
                            'title'          => esc_html__( 'Header Title/Logo Width Option','gutenverse' ),
                            'subtitle'       => esc_html__( 'Choose the width limitation for header logo.','gutenverse' ),
                            'default'        => array(
                                'width'  => 300,
                            )
                        ),

                        array(
                            'id'       => 'gutenverse-spacing-header',
                            'type'     => 'spacing',
                            'output'   => array( '#titles,.header_fix' ),
                            'mode'     => 'margin',
                            'all'      => false,
                            'right'         => false,    
                            'left'          => false,     
                            'units'         => 'px',      
                            'title'    => esc_html__( 'Header Title/Logo Spacing','gutenverse' ),
                            'subtitle' => esc_html__( 'Choose the margin for header logo.','gutenverse' ),
                            'default'  => array(
                                'margin-top'    => '15px',
                                'margin-bottom' => '15px',
                            )
                        ),
						

                        array(
                            'id'       => 'gutenverse-spacing-nav',
                            'type'     => 'spacing',
                            'output'   => array( '#main-nav,.head_extend,#header ul.social-menu' ),
                            'mode'     => 'margin',
                            'all'      => false,
                            'right'         => false,    
                            'left'          => false,       
                            'units'         => 'px',      
                            'title'    => esc_html__( 'Header Navigation Spacing','gutenverse' ),
                            'subtitle' => esc_html__( 'Choose the margin for header navigation.','gutenverse' ),
                            'default'  => array(
                                'margin-top'    => '15px',
                                'margin-bottom'    => '15px',
                            )
                        ),


					// section end
                    )
                );
				// header styling THE END






                $this->sections[] = array(
                    'title'  => esc_html__( 'Footer Styling','gutenverse' ),
                    'desc'   => esc_html__( '','gutenverse' ),
                    'icon'   => 'el el-tint',
                    'fields' => array( // header end
						
						array(
                            'id'       => 'tmnf-footer-editor',
                            'type'     => 'textarea',
                            'title'    => esc_html__( 'Footer Text','gutenverse' ),
                            'subtitle' => esc_html__( 'Just like a text box widget.','gutenverse' ),
                            'desc'     => esc_html__( 'This field is HTML validated!','gutenverse' ),
							'default'  => '',
                            'validate' => 'html',
						),
						
						array(
							'id'        => 'gutenverse-color-myfooter',
							'type'      => 'background',
							'title'     => esc_html__('Footer Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a background color for footer.','gutenverse'),
							
                            'output'   => array('#footer,#footer .searchform input.s' ),
                            'default'     => array(
                                'background-color'       => '#e6ecf5',
                            ),
						),
						
						array(
							'id'        => 'gutenverse-color-wrapper',
							'type'      => 'color',
							'title'     => esc_html__('Social Icons / Newsletter Form Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a background color','gutenverse'),
							'default'   => '#e6ecf5',
							'output'    => array(
								'background-color' => '.mailchimp_section,.footer_icons'
							)
						),
						
						array(
							'id'        => 'gutenverse-links-myfooter',
							'type'      => 'color',
							'title'     => esc_html__('Footer Links - Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for footer links.','gutenverse'),
							'default'   => '#000',
							'output'    => array(
								'color' => '#footer,#footer a,#footer h2,#footer h3,#footer h4,#footer h5,#footer .meta,#footer .meta a,#footer ul.social-menu a span,#footer .searchform input.s,.bottom-menu li a',
							)
						),
						
						array(
							'id'        => 'gutenverse-hover-myfooter',
							'type'      => 'color',
							'title'     => esc_html__('Footer Links - Hover Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a hover color for footer links.','gutenverse'),
							'default'   => '#ff4f69',
							'output'    => array(
								'color' => '#footer a:hover',
							)
						),
						
						
                        array(
                            'id'       => 'gutenverse-footer-border',
							'type'      => 'color',
							'title'     => esc_html__('Footer Borders','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for footer borders.','gutenverse'),
							'default'   => '#d7dfed',
							'output'    => array(
								'border-color' => '#footer,#footer h5.widget,#footer .sidebar_item li,#copyright,#footer .tagcloud a,#footer .tp_recent_tweets ul li,#footer .p-border,#footer .searchform input.s,#footer input,.footer-icons ul.social-menu a,.footer_text',
							)
						),


					// section end
                    )
                );
				// footer styling THE END









                $this->sections[] = array(
                    'title'  => esc_html__( 'Typography','gutenverse' ),
                    'desc'   => esc_html__( '','gutenverse' ),
                    'icon'   => 'el el-bold',
                    'fields' => array( // header end


						array(
							'id'   => 'info_normal',
							'type' => 'info',
							'title' => esc_html__('Special Headings','gutenverse'),
							'style' => 'success',
						),


						array(
                            'id'          => 'gutenverse-h1-title',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Site Title','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( '#header h1' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H1.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '900',
                                'font-family' => 'Source Sans Pro',
                                'google'      => true,
                                'font-size'   => '24px',
                            ),
                        ),
						
						array(
                            'id'          => 'gutenverse-h2-post',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Post Titles','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( 'h1.entry-title,h2 .maintitle,h2.maintitle,.item_mag3_big h2.posttitle,.blogger .item_big h2,.block_title h2' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H2.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '700',
                                'font-family' => 'Source Sans Pro',
                                'google'      => true,
                                'font-size'   => '50px',
                            ),
                        ),
						
						array(
                            'id'          => 'gutenverse-h2-list',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Posts List: Titles','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( 'h2.posttitle,.format-quote p.teaser' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H2.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '700',
                                'font-family' => 'Source Sans Pro',
                                'google'      => true,
                                'font-size'   => '28px',
                            ),
                        ),
						
						array(
                            'id'          => 'gutenverse-small-titles',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Small Titles','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( '.show-menu,.tab-post h4,.tptn_title,.nav-previous a,.post-pagination,.tmnf_events_widget a,.post_nav_text,.item_mag3 h2' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H2.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '700',
                                'font-family' => 'Source Sans Pro',
                                'google'      => true,
                                'font-size'   => '18px',
                            ),
                        ),
						
						array(
                            'id'          => 'gutenverse-buttons-typo',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Buttons Font Style','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( '.tptn_posts_widget li::before,cite,.menuClose span,.icon_extend,ul.social-menu a span,a.mainbutton,.owl-nav>div,.submit,.mc4wp-form input,.woocommerce #respond input#submit, .woocommerce a.button,.woocommerce button.button, .woocommerce input.button,.bottom-menu li a' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H5.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '600',
                                'font-family' => 'Poppins',
                                'google'      => true,
                                'font-size'   => '16px',
                            ),
                        ),	
						
						array(
							'id'   => 'info_normal',
							'type' => 'info',
							'title' => esc_html__('In Post Headings','gutenverse'),
							'style' => 'success',
						),
						
						array(
                            'id'          => 'gutenverse-h1',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'H1 Font Style','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( 'h1' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H2.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '700',
                                'font-family' => 'Source Sans Pro',
                                'google'      => true,
                                'font-size'   => '40px',
                            ),
                        ),
						
						array(
                            'id'          => 'gutenverse-h2',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'H2 Font Style','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( 'h2' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H2.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '700',
                                'font-family' => 'Source Sans Pro',
                                'google'      => true,
                                'font-size'   => '34px',
                            ),
                        ),
						
						array(
                            'id'          => 'gutenverse-h3',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'H3 Font Style','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( 'h3' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H3.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '700',
                                'font-family' => 'Source Sans Pro',
                                'google'      => true,
                                'font-size'   => '28px',
                            ),
                        ),
						
						array(
                            'id'          => 'gutenverse-h4',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'H4 Font Style','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( 'h4,h3#reply-title,.entry h5, .entry h6' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H4.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '700',
                                'font-family' => 'Source Sans Pro',
                                'google'      => true,
                                'font-size'   => '24px',
                            ),
                        ),
						
						array(
                            'id'          => 'gutenverse-h5',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'H5 + H6 Font Style','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( 'h5,h6,.block_title span' ),
                            'units'       => 'px',
                            'line-height' => false,
                            'subtitle'    => esc_html__( 'Select the typography for heading H5.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#002044',
                                'font-weight'  => '700',
                                'font-family' => 'Poppins',
                                'google'      => true,
                                'font-size'   => '14px',
                            ),
                        ),	
						


					// section end
                    )
                );
				// typography styling THE END










                $this->sections[] = array(
                    'title'  => esc_html__( 'Other Styling','gutenverse' ),
                    'desc'   => esc_html__( '','gutenverse' ),
                    'icon'   => 'el el-tint',
                    'fields' => array( // header end
						
	
						
						array(
                            'id'          => 'gutenverse-meta',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Meta Sections - Font Style','gutenverse' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => false,
                            'output'      => array( '.meta,.meta a,.tptn_date,.post_nav_text span' ),
                            'units'       => 'px',
                            'subtitle'    => esc_html__( 'Select the typography for meta sections.','gutenverse' ),
                            'default'     => array(
                                'color'       => '#444',
                                'font-weight'  => '500',
                                'font-family' => 'Poppins',
                                'google'      => true,
                                'font-size'   => '11px',
                                'line-height' => '18px'
                            ),
                        ),
						
						array(
							'id'        => 'gutenverse-color-elements',
							'type'      => 'color',
							'title'     => esc_html__('Elements Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a custom background color for main buttons, special sections etc.','gutenverse'),
							'default'   => '#ff4f69',
							'output'    => array(
								'background-color' => 'a.searchSubmit,.sticky:after,.ribbon,.post_pagination_inn,h2.block_title,.format-quote .item_inn,.woocommerce #respond input#submit,.woocommerce a.button,.woocommerce button.button.alt,.woocommerce button.button,.woocommerce a.button.alt.checkout-button,input#place_order,.woocommerce input.button,#respond #submit,li.current a,.page-numbers.current,a.mainbutton,#submit,#comments .navigation a,.contact-form .submit,.wpcf7-submit,.meta_deko:after,.owl-nav>div,h3#reply-title:after',
								'border-color' => 'input.button,button.submit,.entry blockquote',
								'color' => '.meta_more a',
							)
						),
						
						array(
							'id'        => 'gutenverse-text-elements',
							'type'      => 'color',
							'title'     => esc_html__('Elements Links/Texts - Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a custom text color for main buttons, special sections etc.','gutenverse'),
							'default'   => '#fff',
							'output'    => array(
								'color' => 'a.searchSubmit,.sticky:after,.ribbon,.ribbon a,.ribbon p,#footer .ribbon,h2.block_title,.woocommerce #respond input#submit,.woocommerce a.button,.woocommerce button.button.alt, .woocommerce button.button,.woocommerce a.button.alt.checkout-button,input#place_order,.woocommerce input.button,#respond #submit,.tmnf_icon,a.mainbutton,#submit,#comments .navigation a,.tagssingle a,.wpcf7-submit,.page-numbers.current,.owl-nav>div,.format-quote .item_inn p,.format-quote a,.post_pagination_inn a,.owl-nav>div:before,.mc4wp-form input[type="submit"]',
							
								'background-color' => '.owl-nav>div:after',
							)
						),
						
						array(
							'id'        => 'gutenverse-hover-color-elements',
							'type'      => 'color',
							'title'     => esc_html__('Elements Background Hover Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a custom background color for main buttons, special sections etc.','gutenverse'),
							'default'   => '#e1e5ea',
							'output'    => array(
								'background-color' => 'a.searchSubmit:hover,.ribbon:hover,a.mainbutton:hover,.entry a.ribbon:hover,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover,.owl-nav>div:hover',
								'border-color' => 'input.button:hover,button.submit:hover'
							)
						),
						
						array(
							'id'        => 'gutenverse-hover-text-elements',
							'type'      => 'color',
							'title'     => esc_html__('Elements Links/Texts - Hover Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a custom text color for main buttons, special sections etc.','gutenverse'),
							'default'   => '#465863',
							'output'    => array(
								'color' => '.ribbon:hover,.ribbon:hover a,.ribbon a:hover,.entry a.ribbon:hover,a.mainbutton:hover,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover,.owl-nav>div:hover,.owl-nav>div:hover:before,.mc4wp-form input[type="submit"]:hover',
								'background-color' => '.owl-nav>div:hover:after',
							),
						),
						

						
						array(
							'id'        => 'gutenverse-special-bg',
							'type'      => 'color',
							'title'     => esc_html__('Special Sections: Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a bg color for special sections.','gutenverse'),
							'default'   => '#e8ecf2',
							'output'    => array(
								'background-color' => '.guten_slider .item_inn,.content_inn .mc4wp-form,.tptn_posts_widget li::before,.block_title::after',
							)
						),
						
						
						array(
							'id'        => 'gutenverse-special-text',
							'type'      => 'color',
							'title'     => esc_html__('Special Sections: Text/Link Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a color for text in special sections.','gutenverse'),
							'default'   => '#465863',
							'output'    => array(
								'color' => '.guten_slider .item_inn a,.guten_slider .item_inn p,.content_inn .mc4wp-form,.tptn_posts_widget li::before',
							)
						),
						
						array(
							'id'        => 'gutenverse-images-bg',
							'type'      => 'color',
							'title'     => esc_html__('Images: Background Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a custom bg color for images','gutenverse'),
							'default'   => '#192126',
							'output'    => array(
								'background-color' => '.has-post-thumbnail .imgwrap,.page_hero,.main_slider_wrap',
							)
						),
						
						array(
							'id'        => 'gutenverse-images-text',
							'type'      => 'color',
							'title'     => esc_html__('Images: Text Color','gutenverse'),
							'subtitle'  => esc_html__('Pick a custom bg color for images','gutenverse'),
							'default'   => '#fff',
							'output'    => array(
								'color' => '.page_hero p,.page_hero h1,.page_hero a,.item_big.has-post-thumbnail p,.item_big.has-post-thumbnail h2 a,.item_big.has-post-thumbnail .meta_deko a,.has-post-thumbnail .item_inn_over a,.has-post-thumbnail .item_inn_over p,.guten_main_slider a,.guten_main_slider p',
							)
						),
						


					// section end
                    )
                );
				// other styling THE END









                $this->sections[] = array(
                    'type' => 'divide',
                );	



                
                $this->sections[] = array(
                    'title'  => esc_html__( 'Post Settings','gutenverse' ),
                    'desc'   => esc_html__( '','gutenverse' ),
                    'icon'   => 'el el-edit',
                    'fields' => array( // header end					

						
                        array(
                            'id'       => 'tmnf-post-meta-dis',
                            'type'     => 'checkbox',
                            'title'    => esc_html__( 'Disable "Meta" sections','gutenverse' ),
                            'subtitle' => esc_html__( 'Tick to disable post "inforamtions" - date, category etc. below post titles','gutenverse' ),
                            'desc'     => esc_html__( '','gutenverse' ),
                            'default'  => '0'// 1 = on | 0 = off
                        ),
						
						array(
                            'id'       => 'tmnf-post-nextprev-dis',
                            'type'     => 'checkbox',
                            'title'    => esc_html__( 'Enable Next/Previous Post Section','gutenverse' ),
                            'subtitle' => esc_html__( 'Tick to disable Next/Previous section in single post page.','gutenverse' ),
                            'desc'     => esc_html__( '','gutenverse' ),
                            'default'  => '1'// 1 = on | 0 = off
                        ),
						
						array(
                            'id'       => 'tmnf-post-likes-dis',
                            'type'     => 'checkbox',
                            'title'    => esc_html__( 'Enable Tags Section','gutenverse' ),
                            'subtitle' => esc_html__( 'Tick to disable likes/tags section in single post page.','gutenverse' ),
                            'desc'     => esc_html__( '','gutenverse' ),
                            'default'  => '1'// 1 = on | 0 = off
                        ),
						
						array(
                            'id'       => 'tmnf-post-related-dis',
                            'type'     => 'checkbox',
                            'title'    => esc_html__( 'Enable Related posts Section','gutenverse' ),
                            'subtitle' => esc_html__( 'Tick to disable related section in single post page.','gutenverse' ),
                            'desc'     => esc_html__( '','gutenverse' ),
                            'default'  => '1'// 1 = on | 0 = off
                        ),
						
					
					
					// section end
                    )
                );
				// post settings THE END





                
          $this->sections[] = array(
                    'title'  => esc_html__( 'Social Networks','gutenverse'),
                    'icon'   => 'el el-share',
                    'fields' => array( // header end
				
					

						
						array(
                            'id'       => 'tmnf-search-bottom-dis',
                            'type'     => 'checkbox',
                            'title'    => esc_html__( 'Enable Social Networks Section (in the footer)','gutenverse' ),
                            'subtitle' => esc_html__( 'You can enable section here.','gutenverse' ),
                            'default'  => '0'// 1 = on | 0 = off
                        ),

                        array(
                            'id'       => 'tmnf-social-rss',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Rss Feed','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
                        array(
                            'id'       => 'tmnf-social-facebook',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Facebook','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-twitter',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Twitter','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-pinterest',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Pinterest','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-instagram',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Instagram','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-youtube',
                            'type'     => 'text',
                            'title'    => esc_html__( 'YouTube','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-vimeo',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Vimeo','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-tumblr',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Tumblr','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-500',
                            'type'     => 'text',
                            'title'    => esc_html__( '500px','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-flickr',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Flickr','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-linkedin',
                            'type'     => 'text',
                            'title'    => esc_html__( 'LinkedIn','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-tripadvisor',
                            'type'     => 'text',
                            'title'    => esc_html__( 'TripAdvisor','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						
                        array(
                            'id'       => 'tmnf-social-foursquare',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Foursquare','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
												
                        array(
                            'id'       => 'tmnf-social-dribbble',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Dribbble','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
												
                        array(
                            'id'       => 'tmnf-social-skype',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Skype','gutenverse'),
                            'subtitle' => esc_html__( 'Enter skype URL','gutenverse'),
                        ),
						
												
                        array(
                            'id'       => 'tmnf-social-stumbleupon',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Stumbleupon','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
												
                        array(
                            'id'       => 'tmnf-social-github',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Github','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
												
                        array(
                            'id'       => 'tmnf-social-soundcloud',
                            'type'     => 'text',
                            'title'    => esc_html__( 'SoundCloud','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
												
                        array(
                            'id'       => 'tmnf-social-spotify',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Spotify','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
												
                        array(
                            'id'       => 'tmnf-social-xing',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Xing','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
												
                        array(
                            'id'       => 'tmnf-social-whatsapp',
                            'type'     => 'text',
                            'title'    => esc_html__( 'WhatsApp','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
												
                        array(
                            'id'       => 'tmnf-social-vk',
                            'type'     => 'text',
                            'title'    => esc_html__( 'VK','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
												
                        array(
                            'id'       => 'tmnf-social-snapchat',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Snapchat','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
						
						

					// section end
                    )
                );
				// social networks THE END	
				
				
				
				                $this->sections[] = array(
                    'title'  => esc_html__( 'Static Ads','gutenverse'),
                    'icon'   => 'el el-website',
                    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
                    'fields' => array(


						array(
                            'id'       => 'tmnf-headad-script',
                            'type'     => 'textarea',
                            'title'    => esc_html__( 'Header Script Code','gutenverse'),
                            'desc'     => esc_html__( 'Put your code here','gutenverse'),
							'default'  => '',
						),

                        array(
                            'id'       => 'tmnf-headad-image',
                            'type'     => 'media',
							'default'  => '',
							'readonly' => false,
                            'preview'  => true,
							'url'      => true,
                            'title'    => esc_html__( 'Header Ad - image','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL of your ad image (banner)','gutenverse'),
                        ),
						
						
                        array(
                            'id'       => 'tmnf-headad-target',
                            'type'     => 'text',
                            'title'    => esc_html__( 'Header Ad - target URL','gutenverse'),
                            'subtitle' => esc_html__( 'Enter full URL','gutenverse'),
                            'validate' => 'url',
                            //                        'text_hint' => array(
                            //                            'title'     => '',
                            //                            'content'   => 'Please enter a valid <strong>URL</strong> in this field.'
                            //                        )
                        ),
				
					// section end
                    )
                );
				// custom footer THE END	


            


				

                $this->sections[] = array(
                    'type' => 'divide',
                );		

                

                $this->sections[] = array(
                    'title'  => esc_html__( 'Import / Export','gutenverse' ),
                    'desc'   => esc_html__( 'Import and Export your Redux Framework settings from file, text or URL.','gutenverse' ),
                    'icon'   => 'el el-refresh',
                    'fields' => array(
                        array(
                            'id'         => 'opt-import-export',
                            'type'       => 'import_export',
                            'title'      => 'Import Export',
                            'subtitle'   => 'Save and restore your Redux options',
                            'full_width' => false,
                        ),
                    ),
                );


            }
			
			

            public function setHelpTabs() {

                // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
                $this->args['help_tabs'][] = array(
                    'id'      => 'redux-help-tab-1',
                    'title'   => esc_html__( 'Theme Information 1','gutenverse' ),
                    'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>','gutenverse' )
                );

                $this->args['help_tabs'][] = array(
                    'id'      => 'redux-help-tab-2',
                    'title'   => esc_html__( 'Theme Information 2','gutenverse' ),
                    'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>','gutenverse' )
                );

                // Set the help sidebar
                $this->args['help_sidebar'] = esc_html__( '<p>This is the sidebar content, HTML is allowed.</p>','gutenverse' );
            }

            /**
             * All the possible arguments for Redux.
             * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
             * */
            public function setArguments() {

                $theme = wp_get_theme(); // For use with some settings. Not necessary.

                $this->args = array(
                    // TYPICAL -> Change these values as you need/desire
                    'opt_name'             => 'themnific_redux',
                    // This is where your data is stored in the database and also becomes your global variable name.
                    'display_name'         => $theme->get( 'Name' ),
                    // Name that appears at the top of your panel
                    'display_version'      => $theme->get( 'Version' ),
                    // Version that appears at the top of your panel
                    'menu_type'            => 'menu',
                    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                    'allow_sub_menu'       => true,
                    // Show the sections below the admin menu item or not
                    'menu_title'           => esc_html__( 'GutenVerse - admin panel','gutenverse' ),
                    'page_title'           => esc_html__( 'GutenVerse admin panel','gutenverse' ),
                    // You will need to generate a Google API key to use this feature.
                    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                    'google_api_key'       => '',
                    // Set it you want google fonts to update weekly. A google_api_key value is required.
                    'google_update_weekly' => false,
                    // Must be defined to add google fonts to the typography module
                    'async_typography'     => false,
                    // Use a asynchronous font on the front end or font string
                    //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
                    'admin_bar'            => true,
                    // Show the panel pages on the admin bar
                    'admin_bar_icon'     => 'dashicons-portfolio',
                    // Choose an icon for the admin bar menu
                    'admin_bar_priority' => 50,
                    // Choose an priority for the admin bar menu
                    'global_variable'      => '',
                    // Set a different name for your global variable other than the opt_name
                    'dev_mode'             => false,
					
					'forced_dev_mode_off' => false,
					
                    // Show the time the page took to load, etc
                    'update_notice'        => false,
                    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
                    'customizer'           => true,
                    // Enable basic customizer support
                    //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
                    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

                    // OPTIONAL -> Give you extra features
                    'page_priority'        => null,
                    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                    'page_parent'          => 'themes.php',
                    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                    'page_permissions'     => 'manage_options',
                    // Permissions needed to access the options panel.
                    'menu_icon'            => '',
                    // Specify a custom URL to an icon
                    'last_tab'             => '',
                    // Force your panel to always open to a specific tab (by id)
                    'page_icon'            => 'icon-themes',
                    // Icon displayed in the admin panel next to your menu_title
                    'page_slug'            => 'themnific-options',
                    // Page slug used to denote the panel
                    'save_defaults'        => true,
                    // On load save the defaults to DB before user clicks save or not
                    'default_show'         => false,
                    // If true, shows the default value next to each field that is not the default value.
                    'default_mark'         => '',
                    // What to print by the field's title if the value shown is default. Suggested: *
                    'show_import_export'   => true,
                    // Shows the Import/Export panel when not used as a field.

                    // CAREFUL -> These options are for advanced use only
                    'transient_time'       => 60 * MINUTE_IN_SECONDS,
                    'output'               => true,
                    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                    'output_tag'           => true,
                    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                    // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

                    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                    'database'             => '',
                    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                    'system_info'          => false,
                    // REMOVE

                    // HINTS
                    'hints'                => array(
                        'icon'          => 'el el-question-sign',
                        'icon_position' => 'right',
                        'icon_color'    => 'lightgray',
                        'icon_size'     => 'normal',
                        'tip_style'     => array(
                            'color'   => 'light',
                            'shadow'  => true,
                            'rounded' => false,
                            'style'   => '',
                        ),
                        'tip_position'  => array(
                            'my' => 'top left',
                            'at' => 'bottom right',
                        ),
                        'tip_effect'    => array(
                            'show' => array(
                                'effect'   => 'slide',
                                'duration' => '500',
                                'event'    => 'mouseover',
                            ),
                            'hide' => array(
                                'effect'   => 'slide',
                                'duration' => '500',
                                'event'    => 'click mouseleave',
                            ),
                        ),
                    )
                );

                // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.



                $this->args['admin_bar_links'][] = array(
                    //'id'    => 'redux-support',
                    'href'   => 'http://capethemes.com/docs/gutenverse/',
					'target'   => '_blank',
                    'title' => esc_html__( 'Documentation', 'gutenverse' ),
                );

                // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
                $this->args['share_icons'][] = array(
                    'url'   => 'http://capethemes.com/docs/gutenverse/',
					'target'   => '_blank',
                    'title' => esc_html__( 'Documentation', 'gutenverse' ),
                    'icon'  => 'el el-wrench-alt'
                    //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
                );
                

                // Panel Intro text -> before the form
                if ( ! isset( $this->args['global_variable'] ) || $this->args['global_variable'] !== false ) {
                    if ( ! empty( $this->args['global_variable'] ) ) {
                        $v = $this->args['global_variable'];
                    } else {
                        $v = str_replace( '-', '_', $this->args['opt_name'] );
                    }
                    $this->args['intro_text'] = sprintf( esc_html__( 'Hello in theme admin panel','gutenverse' ), $v );
                } else {
                    $this->args['intro_text'] = esc_html__( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>','gutenverse' );
                }

                // Add content after the form.
                $this->args['footer_text'] = esc_html__( 'Redux & Vergo & Themnific','gutenverse' );
            }

            public function validate_callback_function( $field, $value, $existing_value ) {
                $error = true;
                $value = 'just testing';

                /*
              do your validation

              if(something) {
                $value = $value;
              } elseif(something else) {
                $error = true;
                $value = $existing_value;
                
              }
             */

                $return['value'] = $value;
                $field['msg']    = 'your custom error message';
                if ( $error == true ) {
                    $return['error'] = $field;
                }

                return $return;
            }

            public static function class_field_callback( $field, $value ) {
                print_r( $field );
                echo '<br/>';
                print_r( $value );
            }

        }

        global $reduxConfig;
        $reduxConfig = new gutenverse_redux_config();
    } else {
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ):
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    endif;

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ):
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error = true;
            $value = 'just testing';

            /*
          do your validation

          if(something) {
            $value = $value;
          } elseif(something else) {
            $error = true;
            $value = $existing_value;
            
          }
         */

            $return['value'] = $value;
            $field['msg']    = 'your custom error message';
            if ( $error == true ) {
                $return['error'] = $field;
            }

            $return['warning'] = $field;

            return $return;
        }
    endif;


// TMNF admin panel styling	
function gutenverse__add_css() {
    wp_register_style(
        'redux-tmnf-css',
        get_template_directory_uri() .'/redux-framework/assets/redux-themnific.css',
        array( 'redux-admin-css' ),
        time(),
        'all'
    ); 
    wp_enqueue_style('redux-tmnf-css');
}
add_action( 'redux/page/themnific_redux/enqueue', 'gutenverse__add_css' );


// remove redux notices
function gutenverse_remove_redux_notices() { 
    if ( class_exists('ReduxFrameworkPlugin') ) {
        remove_filter( 'plugin_row_meta', array( ReduxFrameworkPlugin::get_instance(), 'plugin_metalinks'), null, 2 );
    }
    if ( class_exists('ReduxFrameworkPlugin') ) {
        remove_action('admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );    
    }
}
add_action('init', 'gutenverse_remove_redux_notices');