<?php

/*-----------------------------------------------------------------------------------
- Default
----------------------------------------------------------------------------------- */

add_action( 'after_setup_theme', 'gutenverse_theme_setup' );

function gutenverse_theme_setup() {
	global $content_width;

	/* Set the $content_width for things such as video embeds. */
	if ( !isset( $content_width ) )
		$content_width = 2600;

	/* Add theme support for automatic feed links. */
	add_theme_support( 'post-formats', array( 'video','audio', 'gallery','quote', 'link', 'aside' ) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'custom-background' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	
	
	/* Add theme support for post thumbnails (featured images). */	
	add_theme_support('post-thumbnails');
	add_image_size('gutenverse_blog_big', 878, 700, true ); 		//(cropped)
	add_image_size('gutenverse_blog', 409, 320, true ); 		//(cropped)
	add_image_size('gutenverse_single', 870, 600, true ); 		//(cropped)
	

	/* Add custom menus */
	register_nav_menus(array(
		'main-menu' => esc_html__( 'Main Menu','gutenverse' ),
		'bottom-menu' => esc_html__( 'Footer Menu','gutenverse' ),
	));

	/* Add your sidebars function to the 'widgets_init' action hook. */
	add_action( 'widgets_init', 'gutenverse_register_sidebars' );
	
	/* Make theme available for translation */
	load_theme_textdomain('gutenverse', get_template_directory() . '/lang' );

}

function gutenverse_register_sidebars() {
	
	register_sidebar(array('name' => esc_html__( 'Sidebar','gutenverse' ),'id' => 'tmnf-sidebar','description' => esc_html__( 'Sidebar widget section (displayed on posts / blog)','gutenverse' ),'before_widget' => '<div class="sidebar_item">','after_widget' => '</div>','before_title' => '<h5 class="widget"><span>','after_title' => '</span></h5>'));
	
	register_sidebar(array('name' => esc_html__( 'Sidebar (Fly Off)','gutenverse' ),'id' => 'tmnf-sidebar-flyoff','description' => esc_html__( 'Sidebar widget section (hidden, accessible via menu button)','gutenverse' ),'before_widget' => '<div class="sidebar_item">','after_widget' => '</div>','before_title' => '<h5 class="widget"><span>','after_title' => '</span></h5>'));

	
	//footer widgets
	register_sidebar(array('name' => esc_html__( 'Footer 1','gutenverse' ),'id' => 'tmnf-footer-1','description' => esc_html__( 'Widget section in footer - left','gutenverse' ),'before_widget' => '<div class="sidebar_item">','after_widget' => '</div>','before_title' => '<h5 class="widget">','after_title' => '</h5>'));
	register_sidebar(array('name' => esc_html__( 'Footer 2','gutenverse' ),'id' => 'tmnf-footer-2','description' => esc_html__( 'Widget section in footer - center/left','gutenverse' ),'before_widget' => '<div class="sidebar_item">','after_widget' => '</div>','before_title' => '<h5 class="widget">','after_title' => '</h5>'));
	register_sidebar(array('name' => esc_html__( 'Footer 3','gutenverse' ),'id' => 'tmnf-footer-3','description' => esc_html__( 'Widget section in footer - center/right','gutenverse' ),'before_widget' => '<div class="sidebar_item">','after_widget' => '</div>','before_title' => '<h5 class="widget">','after_title' => '</h5>'));
	register_sidebar(array('name' => esc_html__( 'Footer 4','gutenverse' ),'id' => 'tmnf-footer-4','description' => esc_html__( 'Widget section in footer - right','gutenverse' ),'before_widget' => '<div class="sidebar_item">','after_widget' => '</div>','before_title' => '<h5 class="widget">','after_title' => '</h5>'));
	
	//woo widgets
	if ( class_exists( 'WooCommerce' ) ) {
		register_sidebar(array('name' => esc_html__( 'Shop Sidebar','gutenverse' ),'id' => 'tmnf-shop-sidebar','description' => esc_html__( 'Sidebar widget section (displayed on shop pages)','gutenverse' ),'before_widget' => '<div class="sidebar_item">','after_widget' => '</div>','before_title' => '<h5 class="widget"><span>','after_title' => '</span></h5>'));
	}
	
}

//Add a pingback url auto-discovery header for single posts, pages, or attachments.

function gutenverse_pingback_header() {
	if ( is_singular() && pings_open() ) {
		echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
	}
}
add_action( 'wp_head', 'gutenverse_pingback_header' );
	
/*-----------------------------------------------------------------------------------
- Framework - Please refrain from editing this section 
----------------------------------------------------------------------------------- */


// Set path to Framework and theme specific functions
$functions_path = get_template_directory() . '/functions/';

// Theme specific functionality
require_once ($functions_path . 'admin-functions.php');					// Custom functions and plugins

require_once ($functions_path . 'posttypes/post-metabox.php'); 			// custom meta box

// Add Redux options panel
if ( !isset( $themnific_redux ) && file_exists( get_template_directory()  . '/redux-framework/redux-themnific.php' ) ) {
    require_once( get_template_directory()  . '/redux-framework/redux-themnific.php' );
}

	
/*-----------------------------------------------------------------------------------
- Enqueues scripts and styles for front end
----------------------------------------------------------------------------------- */ 

function gutenverse_enqueue_style() {
	
	// Main stylesheet
	wp_enqueue_style( 'gutenverse-style', get_stylesheet_uri());
	
	// Font Awesome css	
	wp_enqueue_style('gutenverse-addons', get_template_directory_uri() .	'/styles/gutenverse-addons.css');
	
	// Font Awesome css	
	wp_enqueue_style('fontawesome', get_template_directory_uri() .	'/styles/fontawesome.css');
	
}
add_action( 'wp_enqueue_scripts', 'gutenverse_enqueue_style' );




// themnific custom css + chnage the order of how the sytlesheets are loaded, and overrides WooCommerce styles.
function gutenverse_custom_order() {
	
	// place wooCommerce styles before our main stlesheet
	if ( class_exists( 'WooCommerce' ) ) {
		wp_dequeue_style( 'woocommerce_frontend_styles' );
		wp_enqueue_style('woocommerce-frontend-styles', plugins_url() .'/woocommerce/assets/css/woocommerce.css');
	
		wp_enqueue_style('gutenverse-woo-custom', get_template_directory_uri().	'/styles/woo-custom.css');
		wp_enqueue_style('gutenverse-mobile', get_template_directory_uri().'/style-mobile.css');
	} else {
		wp_enqueue_style('gutenverse-mobile', get_template_directory_uri().'/style-mobile.css');
	}
}
add_action('wp_enqueue_scripts', 'gutenverse_custom_order');


function gutenverse_enqueue_script() {	

		// Load Common scripts	
		wp_enqueue_script('gutenverse-ownscript', get_template_directory_uri() .'/js/ownScript.js',array( 'jquery' ),'', true);

		// Singular comment script		
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
			wp_enqueue_script( 'comment-reply' );

}
	
add_action('wp_enqueue_scripts', 'gutenverse_enqueue_script');



/*-----------------------------------------------------------------------------------
- TGM_Plugin_Activation class.
----------------------------------------------------------------------------------- */
require_once get_template_directory()  . '/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'gutenverse_register_required_plugins' );
function gutenverse_register_required_plugins() {

    $plugins = array(
	

        // redux-framework
        array(
            'name'				=> esc_html__( 'Redux Framework','gutenverse' ),
            'slug'      		=> 'redux-framework',
            'required'  		=> true,
        ),     
        // elementor
        array(
            'name'				=> esc_html__( 'Elementor','gutenverse' ),
            'slug'      		=> 'elementor',
            'required'  		=> true,
        ),          
		// gutenverse-addons
        array(
            'name'				=> esc_html__( 'GutenVerse Addons','gutenverse' ),
            'slug'      		=> 'gutenverse-addons',
			'source'            => 'http://themnific.com/?ddownload=517', // The plugin source.
            'required'  		=> true,
        ),       
        // one-click-demo-import
        array(
            'name'				=> esc_html__( 'One Click Demo Import','gutenverse' ),
            'slug'      		=> 'one-click-demo-import',
            'required'  		=> false,
        ),      
        // top-10
        array(
            'name'				=> esc_html__( 'Top 10','gutenverse' ),
            'slug'      		=> 'top-10',
            'required'  		=> false,
        ),

    );
    $config = array(
        'id'           => 'tgmpa',                 // Unique ID for hashing notices for multiple instances of TGMPA.
        'default_path' => '',                      // Default absolute path to pre-packaged plugins.
        'menu'         => 'tgmpa-install-plugins', // Menu slug.
        'has_notices'  => true,                    // Show admin notices or not.
        'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
        'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
        'is_automatic' => false,                   // Automatically activate plugins after installation or not.
        'message'      => '',                      // Message to output right before the plugins table.
        'strings'      => array(
            'page_title'                      => esc_html__( 'Install Required Plugins','gutenverse' ),
            'menu_title'                      => esc_html__( 'Install Plugins','gutenverse' ),
            'installing'                      => esc_html__( 'Installing Plugin: %s','gutenverse' ), // %s = plugin name.
            'oops'                            => esc_html__( 'Something went wrong with the plugin API.','gutenverse' ),
            'notice_can_install_required'     => _n_noop( 'This theme requires the following plugin: %1$s.','This theme requires the following plugins: %1$s.','gutenverse' ), // %1$s = plugin name(s).
            'notice_can_install_recommended'  => _n_noop( 'This theme recommends the following plugin: %1$s.','This theme recommends the following plugins: %1$s.','gutenverse' ), // %1$s = plugin name(s).
            'notice_cannot_install'           => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.','gutenverse' ), // %1$s = plugin name(s).
            'notice_can_activate_required'    => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.','gutenverse' ), // %1$s = plugin name(s).
            'notice_can_activate_recommended' => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.','gutenverse' ), // %1$s = plugin name(s).
            'notice_cannot_activate'          => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.','gutenverse' ), // %1$s = plugin name(s).
            'notice_ask_to_update'            => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.','gutenverse' ), // %1$s = plugin name(s).
            'notice_cannot_update'            => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.','gutenverse' ), // %1$s = plugin name(s).
            'install_link'                    => _n_noop( 'Begin installing plugin', 'Begin installing plugins','gutenverse' ),
            'activate_link'                   => _n_noop( 'Begin activating plugin', 'Begin activating plugins','gutenverse' ),
            'return'                          => esc_html__( 'Return to Required Plugins Installer','gutenverse' ),
            'plugin_activated'                => esc_html__( 'Plugin activated successfully.','gutenverse' ),
            'complete'                        => esc_html__( 'All plugins installed and activated successfully. %s','gutenverse' ), // %s = dashboard link.
            'nag_type'                        => 'updated' // Determines admin notice type - can only be 'updated', 'update-nag' or 'error'.
        )
    );

    tgmpa( $plugins, $config );

}

	
/*-----------------------------------------------------------------------------------
- Other theme functions
----------------------------------------------------------------------------------- */

// icons - font awesome
function gutenverse_icon() {
	
	if(has_post_format('audio')) {return '<i title="'. esc_attr__('Audio','gutenverse').'" class="tmnf_icon ribbon fas fa-volume-up"></i>';
	}elseif(has_post_format('gallery')) {return '<i title="'. esc_attr__('Gallery','gutenverse').'" class="tmnf_icon ribbon fas fa-camera"></i>';
	}elseif(has_post_format('image')) {return '<i title="'. esc_attr__('Image','gutenverse').'" class="tmnf_icon ribbon fas fa-camera"></i>';	
	}elseif(has_post_format('link')) {return '<i title="'. esc_attr__('Link','gutenverse').'" class="tmnf_icon ribbon fas fa-link"></i>';			
	}elseif(has_post_format('quote')) {return '<i title="'. esc_attr__('Quote','gutenverse').'" class="tmnf_icon ribbon fas fa-quote-right"></i>';		
	}elseif(has_post_format('video')) {return '<i title="'. esc_attr__('Video','gutenverse').'" class="tmnf_icon ribbon fas fa-play-circle"></i>';
	} else {}	
	
}


// link format
function gutenverse_permalink() {
	$linkformat = get_post_meta(get_the_ID(), 'themnific_linkss', true);
	if($linkformat) echo esc_url($linkformat); else the_permalink();
}


// remove 'Category' word on archives
add_filter( 'get_the_archive_title', function ( $title ) {
    if( is_category() ) {
        $title = single_cat_title( '', false );
    }
    return $title;
});


// new excerpt function

// Old Shorten Excerpt text for use in theme
function gutenverse_excerpt($text, $chars = 1620) {
	$text = $text." ";
	$text = substr($text,0,$chars);
	$text = substr($text,0,strrpos($text,' '));
	$text = $text."";
	return $text;
}

function gutenverse_trim_excerpt($text) {
     $text = str_replace('[', '', $text);
     $text = str_replace(']', '', $text);
     return $text;
    }
add_filter('get_the_excerpt', 'gutenverse_trim_excerpt');


// excerpt class
function gutenverse_class_to_excerpt( $excerpt ){
    return '<div class="tmnf_excerpt">'.$excerpt.'</div>';
}
add_action('the_excerpt','gutenverse_class_to_excerpt');

// meta sections

function gutenverse_meta_front() { ?>   
	<p class="meta meta_deko tranz <?php $themnific_redux = get_option( 'themnific_redux' ); if(isset($themnific_redux['tmnf-post-meta-dis']) ? $themnific_redux['tmnf-post-meta-dis'] : null) echo 'tmnf_hide';?>">
		<span class="post-date"><?php the_time(get_option('date_format')); ?><span class="divider">&bull;</span></span>
        <span class="categs"><?php the_category(', ') ?></span>
        <span class="commes"><?php comments_number( '', esc_html__('• One Comment', 'gutenverse'), esc_html__('• % Comments', 'gutenverse') );?></span>
    </p>
<?php }

function gutenverse_meta_single() { ?>    
	<p class="meta tranz <?php $themnific_redux = get_option( 'themnific_redux' ); if(isset($themnific_redux['tmnf-post-meta-dis']) ? $themnific_redux['tmnf-post-meta-dis'] : null) echo 'tmnf_hide';?>">
        <?php 
		echo '<span class="author"><span>'; esc_html_e('Written by ','gutenverse');echo '</span>'; the_author_posts_link();echo '<span class="divider">&bull;</span></span>';
		?>
        <span class="post-date"><?php the_time(get_option('date_format')); ?><span class="divider">&bull;</span></span>
        <span class="post-time"><?php the_time(); ?><span class="divider">&bull;</span></span>
        <span class="categs"><?php the_category(', ') ?></span>
        <span class="commes"><?php comments_number( '', esc_html__('• One Comment', 'gutenverse'), esc_html__('• % Comments', 'gutenverse') );?></span>
    </p>
<?php
}

function gutenverse_meta_more() { ?>   
	<span class="meta meta_more tranz <?php $themnific_redux = get_option( 'themnific_redux' ); if(isset($themnific_redux['tmnf-post-meta-dis']) ? $themnific_redux['tmnf-post-meta-dis'] : null) echo 'tmnf_hide';?>">
    		<a href="<?php gutenverse_permalink() ?>"><?php esc_html_e('Read More','gutenverse');?> <span class="gimmimore tranz">&rarr;</span></a>

    </span>
<?php }



//////////////GUTENBERG

function gutenverse_gutenberg_styles() {

	// Load the theme styles within Gutenberg.
	wp_enqueue_style( 'gutenverse-gutenberg', get_theme_file_uri( '/styles/gutenberg.css' ), false, '1.1.1', 'all' );

	// Add custom fonts to Gutenberg.
	wp_enqueue_style( 'gutenverse-fonts', gutenverse_fonts_url(), array(), null );
}
add_action( 'enqueue_block_editor_assets', 'gutenverse_gutenberg_styles' );

/**
 * Register custom fonts.
 */
function gutenverse_fonts_url() {
	$fonts_url = '';
	$sourcesans = esc_html_x( 'on', 'Source Sans Pro font: on or off', 'gutenverse' );
	$opensans = esc_html_x( 'on', 'Open Sans font: on or off', 'gutenverse' );

	if ( 'off' !== $sourcesans || 'off' !== $opensans ) {
		$font_families = array();

		if ( 'off' !== $sourcesans ) {
			$font_families[] = 'Source Sans Pro:400,500,600,700,800';
		}

		if ( 'off' !== $opensans ) {
			$font_families[] = 'Open Sans:400,400i,500,600,700';
		}

		$query_args = array(
			'family' => rawurlencode( implode( '|', $font_families ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
		);

		$fonts_url = add_query_arg( $query_args, '//fonts.googleapis.com/css' );
	}

	return esc_url_raw( $fonts_url );
}



// span to default widgets
function gutenverse_cat_count_span($links) {
  $links = str_replace('</a> (', '</a> <span class="cat_nr ribbon">', $links);
  $links = str_replace(')', '</span>', $links);
  return $links;
}
add_filter('wp_list_categories', 'gutenverse_cat_count_span');



function gutenverse_archive_count($links) {
    $links = str_replace('</a>&nbsp;(', '</a> <span class="cat_nr ribbon">', $links);
    $links = str_replace(')', '</span>', $links);
    return $links;
}
add_filter('get_archives_link', 'gutenverse_archive_count');


// overrride plugin's thumbnail
if ( class_exists( 'GutenVerseAddons' ) ) {
		add_image_size('gutenverse_slider_large', 1900, 880, true );		//(cropped)
		add_image_size('gutenverse_slider', 995, 770, true );		//(cropped)
		add_image_size('gutenverse_mag3_big', 630, 650, true );		//(cropped)
		add_image_size('gutenverse_tabs', 100, 100, true );		//(cropped)
		add_image_size('gutenverse_vertical', 400, 500, true );		//(cropped)
}

?>