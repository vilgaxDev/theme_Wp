<?php $themnific_redux = get_option( 'themnific_redux' ); ?>
<div id="titles" class="tranz2">
	<?php if(empty($themnific_redux['tmnf-main-logo']['url'])) { ?>
			<h1><a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name');?></a></h1>
		<?php }
			else { ?>  
				<a class="logo" href="<?php echo esc_url(home_url('/')); ?>">
					<img class="tranz" src="<?php echo esc_url($themnific_redux['tmnf-main-logo']['url']);?>" alt="<?php bloginfo('name'); ?>"/>
				</a>
		<?php } ?>
</div><!-- end #titles  -->