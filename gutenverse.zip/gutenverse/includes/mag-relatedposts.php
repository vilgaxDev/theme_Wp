            <div class="blogger tmnf_related">
			<?php
			$backup = $post;
			$tags = wp_get_post_tags($post->ID);
			if ($tags) { $tag_ids = array();
				foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
				$args=array(
					'tag__in' => $tag_ids,
					'post__not_in' => array($post->ID),
					'showposts'=>4, // Number of related posts that will be shown.
					'ignore_sticky_posts'=>1
				);
				$my_query = new wp_query($args);
				if( $my_query->have_posts() ) { echo '<h3 class="meta_deko related_title"><span>' . esc_html__( 'Related Posts','gutenverse').'</span></h3>'; while ($my_query->have_posts()) { $my_query->the_post();if(has_post_format('aside')){ } else {
			get_template_part('/post-types/post-classic');
			}
					}
					echo '';
				}
			}
			$post = $backup;
			wp_reset_postdata();
			?>
		</div>
		<div class="clearfix"></div>