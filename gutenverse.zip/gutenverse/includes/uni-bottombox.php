		
            <div class="foocol first p-border"> 
            
                <?php if ( is_active_sidebar( 'tmnf-footer-1' ) ) { ?><?php dynamic_sidebar('tmnf-footer-1')?><?php } ?>
                
            </div>
    
            <div class="foocol second p-border"> 
            
                <?php if ( is_active_sidebar( 'tmnf-footer-2' ) ) { ?><?php dynamic_sidebar('tmnf-footer-2')?><?php } ?>
                
            </div>
    
            <div class="foocol third p-border"> 
            
                <?php if ( is_active_sidebar( 'tmnf-footer-3' ) ) { ?><?php dynamic_sidebar('tmnf-footer-3')?><?php } ?>
                
            </div>
        
            <div class="foocol last p-border">
            
                <?php if ( is_active_sidebar( 'tmnf-footer-4' ) ) { ?><?php dynamic_sidebar('tmnf-footer-4') ?><?php } ?>
                
            </div>