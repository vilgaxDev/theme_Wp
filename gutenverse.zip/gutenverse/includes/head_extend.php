<div class="head_extend">
   
    <a class="icon_extend searchOpen" href="#" ><i class=" icon-search-2"></i><span><?php esc_html_e('Search','gutenverse');?></span></a>
    <?php if ( is_active_sidebar( 'tmnf-sidebar-flyoff' ) ) { ?>
    	<a class="icon_extend menuOpen" href="#" ><i class="icon-article"></i><span><?php esc_html_e('Menu','gutenverse');?></span></a>
    <?php } ?>

</div>